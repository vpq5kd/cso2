#!/bin/bash
date >> simple_runs
wc -l < simple_runs
